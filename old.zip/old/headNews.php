<?php
$title = ucfirst($_GET['title']);
?>

<!DOCTYPE html>
<html lang="it">
  
  <head>
  	<meta charset="UTF-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  	<link rel="stylesheet" href="css/main.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/4.1.1/normalize.css"> -->
  
    <title>YWS News - <?php echo $title; ?></title>
  </head>

 <body>
 <script type="text/javascript">
  if (localStorage.getItem('start') == '0') {
    localStorage.setItem('start', '1');
  }
      </script>